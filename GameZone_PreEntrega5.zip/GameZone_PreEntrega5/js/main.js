// SIMULADOR: GESTIÓN DE VIDEOJUEGOS - PRE-ENTREGA 5

// 1) Clase que funciona como molde para crear videojuegos.
class Videojuego {
  constructor(id, nombre, precio, categoria, stock) {
    this.id = id;
    this.nombre = nombre;
    this.precio = precio;
    this.categoria = categoria;
    this.stock = stock;
  }

  calcularPrecioConIVA() {
    return this.precio * 1.21;
  }

  vender(cantidad) {
    if (!Number.isInteger(cantidad) || cantidad <= 0) {
      console.log("La cantidad debe ser un número entero mayor a cero.");
      return false;
    }
    if (this.stock >= cantidad) {
      this.stock -= cantidad;
      console.log(`Se vendieron ${cantidad} unidades de ${this.nombre}.`);
      return true;
    }
    console.log(`No hay suficiente stock de ${this.nombre}. Stock disponible: ${this.stock}.`);
    return false;
  }

  mostrarInformacion() {
    console.log("------------------------------");
    console.log(`ID: ${this.id}`);
    console.log(`Videojuego: ${this.nombre}`);
    console.log(`Precio: $${this.precio}`);
    console.log(`Categoría: ${this.categoria}`);
    console.log(`Stock: ${this.stock}`);
    console.log("------------------------------");
  }
}

// 2) Instancias creadas con el operador new.
const videojuego1 = new Videojuego(1, "Minecraft", 15000, "Aventura", 10);
const videojuego2 = new Videojuego(2, "FIFA 25", 25000, "Deportes", 8);
const videojuego3 = new Videojuego(3, "GTA V", 20000, "Acción", 5);
const videojuego4 = new Videojuego(4, "The Sims 4", 12000, "Simulación", 7);

// 3) Array que reúne los objetos del catálogo.
const catalogoVideojuegos = [videojuego1, videojuego2, videojuego3, videojuego4];

// 4) Se muestran los datos y se ejecutan los métodos.
console.log("===== CATÁLOGO INICIAL =====");
for (const videojuego of catalogoVideojuegos) {
  videojuego.mostrarInformacion();
}

console.log("===== REGISTRO DE VENTAS =====");
videojuego1.vender(2);
videojuego2.vender(1);
videojuego3.vender(3);

console.log("===== PRECIOS CON IVA =====");
console.log(`Minecraft con IVA: $${videojuego1.calcularPrecioConIVA().toFixed(2)}`);
console.log(`FIFA 25 con IVA: $${videojuego2.calcularPrecioConIVA().toFixed(2)}`);

// 5) Destructuring: se extraen propiedades de un objeto.
console.log("===== DESTRUCTURING =====");
const { nombre, precio, categoria } = videojuego1;
console.log(`Nombre: ${nombre}`);
console.log(`Precio: $${precio}`);
console.log(`Categoría: ${categoria}`);

// 6) Spread operator: se copia el array y se agrega otro objeto.
console.log("===== SPREAD OPERATOR =====");
const videojuego5 = new Videojuego(5, "Fortnite", 18000, "Acción", 12);
const copiaCatalogo = [...catalogoVideojuegos];
const nuevoCatalogo = [...copiaCatalogo, videojuego5];

// 7) Función que recorre el catálogo y muestra los datos.
function listarVideojuegos(lista) {
  console.log("===== CATÁLOGO FINAL =====");
  for (const videojuego of lista) {
    console.log(`${videojuego.nombre} - Precio: $${videojuego.precio} - Stock: ${videojuego.stock}`);
  }
  console.log(`Total de videojuegos: ${lista.length}`);
}
listarVideojuegos(nuevoCatalogo);

// 8) Se muestran los objetos en la página web.
function mostrarCatalogo(lista) {
  const contenedor = document.querySelector("#lista-videojuegos");
  const contador = document.querySelector("#cantidad-juegos");

  if (!contenedor || !contador) {
    console.error("No se encontraron los elementos del catálogo en el HTML.");
    return;
  }

  contenedor.innerHTML = "";

  for (const videojuego of lista) {
    const tarjeta = document.createElement("article");
    tarjeta.classList.add("tarjeta");

    const categoriaElemento = document.createElement("span");
    categoriaElemento.classList.add("categoria");
    categoriaElemento.textContent = videojuego.categoria;

    const nombreElemento = document.createElement("h3");
    nombreElemento.textContent = videojuego.nombre;

    const precioElemento = document.createElement("p");
    precioElemento.textContent = `Precio: $${videojuego.precio}`;

    const stockElemento = document.createElement("p");
    stockElemento.textContent = `Stock disponible: ${videojuego.stock}`;

    tarjeta.append(categoriaElemento, nombreElemento, precioElemento, stockElemento);
    contenedor.appendChild(tarjeta);
  }

  contador.textContent = `${lista.length} juegos`;
}

mostrarCatalogo(nuevoCatalogo);
